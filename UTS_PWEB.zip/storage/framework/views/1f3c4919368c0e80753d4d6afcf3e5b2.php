<?php $__env->startSection('content'); ?>
    <h2>Login</h2>
    <form method="POST" action="<?php echo e(route('handleLogin')); ?>">
        <?php echo csrf_field(); ?>
        <label>Username: <input type="text" name="username"></label><br>
        <label>Password: <input type="password" name="password"></label><br>
        <button type="submit">Login</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\snsv\uts_pweb\resources\views/login.blade.php ENDPATH**/ ?>