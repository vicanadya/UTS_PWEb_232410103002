<?php $__env->startSection('content'); ?>
    <h2>Profile Pengguna</h2>
    <p>Selamat datang di halaman profile, <?php echo e($username); ?>!</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\snsv\uts_pweb\resources\views/profile.blade.php ENDPATH**/ ?>