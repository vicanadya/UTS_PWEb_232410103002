<footer>
    <p>© 2025 UTS PWEB</p>
</footer>
<?php /**PATH C:\Users\snsv\uts_pweb\resources\views/components/footer.blade.php ENDPATH**/ ?>