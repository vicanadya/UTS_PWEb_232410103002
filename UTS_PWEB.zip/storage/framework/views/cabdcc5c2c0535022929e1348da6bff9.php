<?php $__env->startSection('content'); ?>
    <h1>Selamat datang, <?php echo e($username); ?>!</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\snsv\uts_pweb\resources\views/dashboard.blade.php ENDPATH**/ ?>