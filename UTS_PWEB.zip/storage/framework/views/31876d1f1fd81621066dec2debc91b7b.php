<!DOCTYPE html>
<html>
<head>
    <title>UTS PWEB</title>
</head>
<body>
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\snsv\uts_pweb\resources\views/layouts/app.blade.php ENDPATH**/ ?>