<?php
    $username = request()->query('username');
?>

<nav>
    <a href="<?php echo e(route('dashboard', ['username' => $username])); ?>">Dashboard</a> |
    <a href="<?php echo e(route('profile', ['username' => $username])); ?>">Profile</a> |
    <a href="<?php echo e(route('pengelolaan', ['username' => $username])); ?>">Pengelolaan</a>
</nav>
<?php /**PATH C:\Users\snsv\uts_pweb\resources\views/components/navbar.blade.php ENDPATH**/ ?>