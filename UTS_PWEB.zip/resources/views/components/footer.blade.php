<footer>
    <p>© 2025 UTS PWEB</p>
</footer>
