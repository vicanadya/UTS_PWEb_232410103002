@extends('layouts.app')

@section('content')
    <h2>Data Pengelolaan</h2>
    <ul>
        @foreach ($data as $item)
            <li>{{ $item['nama'] }} - {{ $item['kategori'] }}</li>
        @endforeach
    </ul>
@endsection
