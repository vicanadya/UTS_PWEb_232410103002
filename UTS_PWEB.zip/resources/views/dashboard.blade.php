@extends('layouts.app')

@section('content')
    <h1>Selamat datang, {{ $username }}!</h1>
@endsection
