@extends('layouts.app')

@section('content')
    <h2>Profile Pengguna</h2>
    <p>Selamat datang di halaman profile, {{ $username }}!</p>
@endsection
